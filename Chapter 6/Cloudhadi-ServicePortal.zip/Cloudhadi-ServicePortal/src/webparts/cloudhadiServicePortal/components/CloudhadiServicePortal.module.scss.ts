/* tslint:disable */
require("./CloudhadiServicePortal.module.css");
const styles = {
  cloudhadiServicePortal: 'cloudhadiServicePortal_d9a15222',
  tabContainer: 'tabContainer_d9a15222',
  tab: 'tab_d9a15222',
  tabIcon: 'tabIcon_d9a15222',
  activeTab: 'activeTab_d9a15222',
  tabContent: 'tabContent_d9a15222',
  container: 'container_d9a15222',
  title: 'title_d9a15222',
  formGrid: 'formGrid_d9a15222',
  fluentControl: 'fluentControl_d9a15222',
  'ms-TextField': 'ms-TextField_d9a15222',
  'ms-Dropdown': 'ms-Dropdown_d9a15222',
  buttonContainer: 'buttonContainer_d9a15222',
  successLabel: 'successLabel_d9a15222',
  errorLabel: 'errorLabel_d9a15222',
  requestList: 'requestList_d9a15222',
  table: 'table_d9a15222',
  buttonList: 'buttonList_d9a15222',
  btnInProgress: 'btnInProgress_d9a15222',
  btnCompleted: 'btnCompleted_d9a15222'
};

export default styles;
/* tslint:enable */