import {WebPartContext} from '@microsoft/sp-webpart-base';
export interface IRequestListProps {
   context:WebPartContext,
   isServiceUser:boolean
}
