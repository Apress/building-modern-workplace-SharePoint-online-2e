/// <reference types="react" />
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/site-users/web";
import { IRequestDetailsProps } from "./IRequestDetailsProps";
declare const RequestDetails: (props: IRequestDetailsProps) => JSX.Element;
export default RequestDetails;
//# sourceMappingURL=RequestDetails.d.ts.map