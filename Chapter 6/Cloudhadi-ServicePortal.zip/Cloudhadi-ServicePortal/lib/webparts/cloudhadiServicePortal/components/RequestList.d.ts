/// <reference types="react" />
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { IRequestListProps } from "./IRequestListProps";
declare const RequestList: (props: IRequestListProps) => JSX.Element;
export default RequestList;
//# sourceMappingURL=RequestList.d.ts.map