/// <reference types="react" />
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/site-users/web";
import { ICloudhadiServicePortalProps } from './ICloudhadiServicePortalProps';
declare const CloudhadiServicePortal: (props: ICloudhadiServicePortalProps) => JSX.Element;
export default CloudhadiServicePortal;
//# sourceMappingURL=CloudhadiServicePortal.d.ts.map