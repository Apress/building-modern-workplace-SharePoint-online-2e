declare const styles: {
    cloudhadiServicePortal: string;
    tabContainer: string;
    tab: string;
    tabIcon: string;
    activeTab: string;
    tabContent: string;
    container: string;
    title: string;
    formGrid: string;
    fluentControl: string;
    'ms-TextField': string;
    'ms-Dropdown': string;
    buttonContainer: string;
    successLabel: string;
    errorLabel: string;
    requestList: string;
    table: string;
    buttonList: string;
    btnInProgress: string;
    btnCompleted: string;
};
export default styles;
//# sourceMappingURL=CloudhadiServicePortal.module.scss.d.ts.map